from games.game_engine import main
if __name__ == '__main__':
    main()