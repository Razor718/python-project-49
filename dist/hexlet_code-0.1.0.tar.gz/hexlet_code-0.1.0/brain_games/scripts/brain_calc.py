from games.calc import main
main()
