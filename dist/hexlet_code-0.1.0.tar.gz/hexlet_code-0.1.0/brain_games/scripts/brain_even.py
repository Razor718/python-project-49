from games.even import main

main()
