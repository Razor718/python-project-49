from games.progression import main
if __name__ == '__main__':
    main()
