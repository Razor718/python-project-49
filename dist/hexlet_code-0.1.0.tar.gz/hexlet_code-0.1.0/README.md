### Hexlet tests and linter status:
[![Actions Status](https://github.com/Razor718/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Razor718/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/02ec0c1bef63b09dda0c/maintainability)](https://codeclimate.com/github/Razor718/python-project-49/maintainability)
